<script setup lang="ts">
import { ref, reactive, watch, onMounted } from 'vue';
import Layout from '@/components/client/Layout.vue';
import FormCard from '@/components/client/Auth/FormCard.vue';
import FormInput from '@/components/client/Auth/FormInput.vue';
import Swal from 'sweetalert2';
import { useSettingsStore } from '@/stores/settings';
const Settings = useSettingsStore();
import Turnstile from 'vue-turnstile';
import { useRouter } from 'vue-router';
import successAlertSfx from '@/assets/sounds/success.mp3';
import failedAlertSfx from '@/assets/sounds/error.mp3';
import { useSound } from '@vueuse/sound';
import Auth from '@/mythicaldash/Auth';
import { MythicalDOM } from '@/mythicaldash/MythicalDOM';

const { play: playError } = useSound(failedAlertSfx);
const { play: playSuccess } = useSound(successAlertSfx);
const router = useRouter();

const loading = ref(false);
const form = reactive({
    firstName: '',
    lastName: '',
    username: '',
    email: '',
    password: '',
    turnstileResponse: '',
    referralCode: '',
});

const referralsEnabled = Settings.getSetting('referrals_enabled');
const acceptTerms = ref(false);
const validationErrors = ref<{ [key: string]: string }>({});

if (router.currentRoute.value.query.ref) {
    form.referralCode = router.currentRoute.value.query.ref as string;
}

MythicalDOM.setPageTitle('Register');

const generateUsername = () => {
    const adjectives = ['happy', 'clever', 'brave', 'swift', 'bright', 'calm', 'eager', 'fair', 'kind', 'lively'];
    const nouns = ['panda', 'tiger', 'eagle', 'dolphin', 'wolf', 'phoenix', 'dragon', 'lion', 'bear', 'fox', 'cat'];
    const numbers = Math.floor(Math.random() * 1000);
    const randomAdj = adjectives[Math.floor(Math.random() * adjectives.length)];
    const randomNoun = nouns[Math.floor(Math.random() * nouns.length)];
    form.username = `${randomAdj}${randomNoun}${numbers}`;
};

const generatePassword = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?';
    let password = '';
    for (let i = 0; i < 16; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    form.password = password;
};


const validateForm = () => {
    validationErrors.value = {};
    if (!form.firstName || !/^[a-zA-Z]+$/.test(form.firstName) || form.firstName.length > 191) {
        validationErrors.value.firstName = 'First name must be 1-191 letters.';
    }
    if (!form.lastName || !/^[a-zA-Z]+$/.test(form.lastName) || form.lastName.length > 191) {
        validationErrors.value.lastName = 'Last name must be 1-191 letters.';
    }
    if (!form.username || form.username.length < 1 || form.username.length > 191 || !/^[a-z0-9]([\w\.-]+)[a-z0-9]$/i.test(form.username)) {
        validationErrors.value.username = 'Username must be 1-191 chars, start/end with alphanumeric, and can contain . - _ in between.';
    }
    if (!form.email || form.email.length < 1 || form.email.length > 191 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
        validationErrors.value.email = 'Please enter a valid email address (1-191 chars).';
    }
    if (!form.password || form.password.length < 8) {
        validationErrors.value.password = 'Password must be at least 8 characters.';
    }

    return Object.keys(validationErrors.value).length === 0;
};

const handleSubmit = async () => {
    if (!acceptTerms.value) {
        playError();
        Swal.fire({
            icon: 'error',
            title: 'Terms not accepted',
            text: 'You must accept the Terms of Service and Privacy Policy to register.',
            showConfirmButton: true,
        });
        return;
    }
    if (!validateForm()) {
        playError();
        Swal.fire({
            icon: 'error',
            title: 'Validation Failed',
            text: 'Please correct the highlighted errors before submitting.',
            showConfirmButton: true,
        });
        return;
    }

    loading.value = true;
    try {
        const response = await Auth.register(
            form.firstName,
            form.lastName,
            form.email,
            form.username,
            form.password,
            form.turnstileResponse,
            form.referralCode,
        );

        if (!response.success) {
            const error_code = response.error_code as string;
            const errorMessages: { [key: string]: string } = {
                'TURNSTILE_FAILED': 'You have been blocked by Cloudflare Turnstile',
                'USERNAME_ALREADY_IN_USE': 'Username already exists',
                'EMAIL_ALREADY_IN_USE': 'Email already exists',
                'DATABASE_ERROR': 'An error occurred. Please try again later',
                'PTERODACTYL_NOT_ENABLED': 'Pterodactyl is not enabled',
                'PTERODACTYL_ERROR': 'Failed to register user in Pterodactyl panel',
                'PROXY_DETECTED': 'You are using a vpn or a proxy!',
            };
            
            const errorMessage = errorMessages[error_code] || response.message || 'An unknown error occurred.';
            
            playError();
            Swal.fire({
                icon: 'error',
                title: 'Registration Failed',
                text: errorMessage,
                footer: 'Please contact support for assistance',
                showConfirmButton: true,
            });
        } else {
            playSuccess();
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'You have successfully registered',
                footer: 'Thanks for choosing us!',
                showConfirmButton: true,
            });
            setTimeout(() => {
                router.push('/auth/login');
            }, 1500);
        }
    } catch (error) {
        console.error('Register failed:', error);
        playError();
        Swal.fire({
            icon: 'error',
            title: 'Registration Failed',
            text: 'An unexpected error occurred.',
            footer: 'Please contact support for assistance',
            showConfirmButton: true,
        });
    } finally {
        loading.value = false;
    }
};
</script>

<template>
    <Layout>
        <FormCard title="Create a new account" @submit="handleSubmit">
            <div class="flex space-x-4">
                <div class="w-1/2">
                    <FormInput
                        id="firstName"
                        label="First Name"
                        v-model="form.firstName"
                        placeholder="Enter your first name"
                        required
                    />
                    <div v-if="validationErrors.firstName" class="text-red-500 text-xs mt-1">
                        {{ validationErrors.firstName }}
                    </div>
                </div>
                <div class="w-1/2">
                    <FormInput
                        id="lastName"
                        label="Last Name"
                        v-model="form.lastName"
                        placeholder="Enter your last name"
                        required
                    />
                    <div v-if="validationErrors.lastName" class="text-red-500 text-xs mt-1">
                        {{ validationErrors.lastName }}
                    </div>
                </div>
            </div>
            <div class="relative">
                <FormInput
                    id="username"
                    label="Username"
                    v-model="form.username"
                    placeholder="Enter your username"
                    required
                />
                <button
                    type="button"
                    @click="generateUsername"
                    title="Generate a random username"
                    class="absolute right-2 top-8 px-2 py-1 text-sm bg-purple-600 hover:bg-purple-700 text-white rounded transition-colors"
                >
                    Generate
                </button>
                <div v-if="validationErrors.username" class="text-red-500 text-xs mt-1">
                    {{ validationErrors.username }}
                </div>
            </div>
            <div>
                <FormInput
                    id="email"
                    label="Email"
                    v-model="form.email"
                    placeholder="Enter your email"
                    type="email"
                    required
                />
                <div v-if="validationErrors.email" class="text-red-500 text-xs mt-1">
                    {{ validationErrors.email }}
                </div>
            </div>
            <div class="flex items-center justify-between mb-2">
                <label class="block text-sm text-gray-400">Password</label>
                <button type="button" @click="generatePassword" class="text-sm text-purple-400 hover:text-purple-300">
                    Generate Password
                </button>
            </div>
            <FormInput
                id="password"
                type="password"
                v-model="form.password"
                :minlength="8"
                placeholder="Enter your password"
                required
            />
            <div v-if="validationErrors.password" class="text-red-500 text-xs mt-1">
                {{ validationErrors.password }}
            </div>
            <div v-if="referralsEnabled == 'true'">
                <FormInput
                    id="referralCode"
                    label="Referral Code"
                    v-model="form.referralCode"
                    placeholder="Enter your referral code"
                />
            </div>

            <div class="flex items-center mt-4">
                <input id="acceptTerms" type="checkbox" v-model="acceptTerms" required class="mr-2" />
                <label for="acceptTerms" class="text-sm text-gray-400">
                    I accept the
                    <a
                        href="/terms-of-service"
                        target="_blank"
                        class="text-purple-400 hover:text-purple-300 underline mx-1"
                    >
                        Terms of Service
                    </a>
                    and
                    <a
                        href="/privacy-policy"
                        target="_blank"
                        class="text-purple-400 hover:text-purple-300 underline mx-1"
                    >
                        Privacy Policy
                    </a>
                </label>
            </div>
            <button
                type="submit"
                class="w-full mt-6 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
                :disabled="loading"
            >
                {{ loading ? 'Registering...' : 'Register' }}
            </button>

            <div
                v-if="Settings.getSetting('turnstile_enabled') == 'true'"
                style="display: flex; justify-content: center; margin-top: 20px"
            >
                <Turnstile :site-key="Settings.getSetting('turnstile_key_pub')" v-model="form.turnstileResponse" />
            </div>

            <p class="mt-4 text-center text-sm text-gray-400">
                Already have an account?
                <router-link to="/auth/login" class="text-purple-400 hover:text-purple-300">
                    Login
                </router-link>
            </p>
        </FormCard>
    </Layout>
</template>