<template>
    <LayoutDashboard>
        <!-- Page Header -->
        <div class="mb-8">
            <h1 class="text-2xl font-bold text-gray-100 mb-2">Account</h1>
            <p class="text-gray-400">Manage your account settings and preferences</p>
        </div>

        <!-- User Profile Card -->
        <LayoutAccount class="mb-8" />

        <!-- Tabs Card -->
        <div class="bg-[#0a0a15]/50 border border-[#1a1a2f]/30 rounded-xl shadow-lg overflow-hidden">
            <!-- Tabs Navigation -->
            <div class="border-b border-[#1a1a2f]/30 bg-[#050508]/70">
                <div class="flex overflow-x-auto scrollbar-hide">
                    <button
                        v-for="tab in tabs"
                        :key="tab.name"
                        class="flex items-center gap-2 px-6 py-4 text-sm font-medium whitespace-nowrap transition-all duration-200"
                        :class="[
                            activeTab === tab.name
                                ? 'text-indigo-400 border-b-2 border-indigo-500 bg-[#0a0a15]/50'
                                : 'text-gray-400 hover:text-gray-200 hover:bg-[#0a0a15]/30',
                        ]"
                        @click="activeTab = tab.name"
                    >
                        <component :is="tab.icon" class="w-4 h-4" />
                        {{ tab.name }}
                    </button>
                </div>
            </div>

            <!-- Tab Content -->
            <div class="p-6">
                <div class="tab-content">
                    <SettingsTab v-if="activeTab === 'Settings'" />
                    <SecurityTab v-if="activeTab === 'Security'" />
                </div>
            </div>
        </div>
    </LayoutDashboard>
</template>

<script setup lang="ts">
import LayoutDashboard from '@/components/client/LayoutDashboard.vue';
import SettingsTab from '@/components/client/Dashboard/Account/Settings.vue';
import SecurityTab from '@/components/client/Dashboard/Account/Security.vue';
import LayoutAccount from '@/components/client/Dashboard/Account/Layout.vue';
import { MythicalDOM } from '@/mythicaldash/MythicalDOM';
import { ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import {
    Settings as SettingsIcon,
    Lock as SecurityIcon,
} from 'lucide-vue-next';

const route = useRoute();
const router = useRouter();

MythicalDOM.setPageTitle('Account');

const availableTabs = ['Settings', 'Security'];

const getInitialTab = () => {
    const tabFromUrl = route.query.tab as string;
    if (tabFromUrl && availableTabs.includes(tabFromUrl)) {
        return tabFromUrl;
    }
    return 'Settings';
};

const activeTab = ref(getInitialTab());

const tabs = [
    { name: 'Settings', icon: SettingsIcon },
    { name: 'Security', icon: SecurityIcon },
];

const updateUrl = (tabName: string) => {
    router.replace({
        query: { ...route.query, tab: tabName },
    });
};

watch(activeTab, (newTab) => {
    updateUrl(newTab);
});

watch(
    () => route.query.tab,
    (newTab) => {
        if (newTab && availableTabs.includes(newTab as string)) {
            activeTab.value = newTab as string;
        }
    },
);
</script>

<style scoped>
/* Hide scrollbar */
.scrollbar-hide::-webkit-scrollbar {
    display: none;
}
.scrollbar-hide {
    -ms-overflow-style: none;
    scrollbar-width: none;
}

/* Tab content animation */
.tab-content {
    animation: fadeIn 0.3s ease-in-out;
}
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(5px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>