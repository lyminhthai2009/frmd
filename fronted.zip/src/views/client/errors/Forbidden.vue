<script setup lang="ts">
import { ShieldAlertIcon } from 'lucide-vue-next';
import ErrorPage from '@/components/client/Errors/ErrorPage.vue';
import { MythicalDOM } from '@/mythicaldash/MythicalDOM';

MythicalDOM.setPageTitle('403 Forbidden');
</script>

<template>
    <ErrorPage
        :icon="ShieldAlertIcon"
        title="403 Forbidden"
        message="Hold it right there, space traveler! You don't have the necessary clearance to access this area."
    />
</template>