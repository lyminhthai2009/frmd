<script setup lang="ts">
import { ServerCrashIcon } from 'lucide-vue-next';
import ErrorPage from '@/components/client/Errors/ErrorPage.vue';
import { MythicalDOM } from '@/mythicaldash/MythicalDOM';

MythicalDOM.setPageTitle('500 Server Error');
</script>
<template>
    <ErrorPage
        :icon="ServerCrashIcon"
        title="500 Server Error"
        message="An error occurred on our end. Please try again later."
    />
</template>