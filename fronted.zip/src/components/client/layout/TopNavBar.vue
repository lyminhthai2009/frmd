<template>
    <nav :class="navClasses" :style="backgroundStyle">
        <div class="h-full px-4 flex items-center justify-between">
            <div class="flex items-center gap-3 flex-shrink-0">
                <button
                    class="lg:hidden p-2 hover:bg-[#1a1a2e]/50 rounded-lg transition-all duration-200 hover:scale-105"
                    @click="$emit('toggle-sidebar')"
                >
                    <MenuIcon v-if="!isSidebarOpen" class="w-5 h-5" />
                    <XIcon v-else class="w-5 h-5" />
                </button>
                <div class="hidden md:flex items-center gap-2 group">
                    <div
                        class="w-8 h-8 flex items-center justify-center bg-[#1a1a2e]/30 rounded-lg transition-all duration-200 group-hover:bg-indigo-500/10 group-hover:scale-105"
                        :class="topNavSettings.borderGlow ? 'shadow-md shadow-indigo-500/20' : ''"
                    >
                        <img :src="appLogo" alt="App Logo" class="h-6 w-6" />
                    </div>
                    <span
                        class="text-xl font-bold bg-gradient-to-r from-indigo-400 to-indigo-600 bg-clip-text text-transparent transition-all duration-200 group-hover:from-indigo-300 group-hover:to-indigo-500 drop-shadow-sm"
                    >
                        {{ appName }}
                    </span>
                </div>
            </div>

            <button
                v-if="topNavSettings.showSearchBar"
                class="lg:hidden p-2 hover:bg-[#1a1a2e]/50 rounded-lg transition-all duration-200 hover:scale-105"
                @click="$emit('toggle-search')"
            >
                <SearchIcon class="w-5 h-5" />
            </button>
            
            <div class="flex items-center gap-2 flex-shrink-0">
                 <button
                    @click="$emit('toggle-profile')"
                    class="hidden lg:flex items-center gap-3 px-3 py-2 hover:bg-[#1a1a2e]/50 rounded-lg transition-all duration-200 group"
                    :class="topNavSettings.borderGlow ? 'hover:shadow-md hover:shadow-indigo-500/20' : ''"
                >
                    <div class="relative">
                        <img
                            :src="Session.getInfo('avatar')"
                            alt="Profile"
                            class="w-8 h-8 rounded-lg ring-2 ring-[#2a2a3f]/30 transition-all duration-200 group-hover:ring-indigo-500/30 group-hover:scale-105"
                        />
                        <div
                            class="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full ring-2 ring-[#0a0a0f]/95 animate-pulse"
                            :class="topNavSettings.borderGlow ? 'shadow-sm shadow-green-500/50' : ''"
                        ></div>
                    </div>
                    <div class="flex flex-col items-start">
                        <span class="text-sm font-medium text-gray-200 group-hover:text-gray-100 transition-colors duration-200 drop-shadow-sm">
                            {{ Session.getInfo('username') }}
                        </span>
                        <span class="text-xs text-gray-400 group-hover:text-gray-300 transition-colors duration-200 drop-shadow-sm">
                           {{ role }}
                        </span>
                    </div>
                </button>
            </div>
        </div>
    </nav>
</template>

<script setup lang="ts">
import {
    Search as SearchIcon,
    User as UserIcon,
    Menu as MenuIcon,
    X as XIcon,
} from 'lucide-vue-next';
import { useSettingsStore } from '@/stores/settings';
import { computed } from 'vue';
import Session from '@/mythicaldash/Session';
import { useSkinSettings } from '@/composables/useSkinSettings';

const role = (Session.getInfo('role_real_name') || 'User').charAt(0).toUpperCase() + (Session.getInfo('role_real_name') || 'User').slice(1);
const { topNavSettings } = useSkinSettings();

const Settings = useSettingsStore();

defineProps<{ isSidebarOpen: boolean; }>();
defineEmits(['toggle-sidebar', 'toggle-search', 'toggle-profile']);

const appLogo = Settings.getSetting('app_logo');
const appName = Settings.getSetting('app_name');

const navClasses = computed(() => {
    const baseClasses = 'fixed top-0 left-0 right-0 h-16 z-30 transition-all duration-200';
    const backgroundClasses = topNavSettings.glassEffect
        ? `bg-[#0a0a0f]/${Math.round(topNavSettings.backgroundOpacity * 100)} backdrop-blur-md`
        : 'bg-[#0a0a0f]';
    const borderClasses = topNavSettings.borderGlow
        ? 'border-b border-[#2a2a3f]/30 shadow-lg shadow-indigo-500/5'
        : 'border-b border-[#2a2a3f]/20';
    return [baseClasses, backgroundClasses, borderClasses].join(' ');
});

const backgroundStyle = computed(() => {
    if (!topNavSettings.glassEffect) return {};
    return {
        backgroundImage: `linear-gradient(135deg, 
            rgba(99, 102, 241, 0.02) 0%, 
            rgba(168, 85, 247, 0.01) 50%, 
            rgba(59, 130, 246, 0.02) 100%)`,
    };
});
</script>