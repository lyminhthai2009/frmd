import { ref, computed } from 'vue';
import {
    LayoutDashboard,
    Users,
    PaperclipIcon,
    SettingsIcon,
    ServerCrash,
    EggIcon,
    Shield,
    Server,
    HeartHandshakeIcon
} from 'lucide-vue-next';
import type { MenuGroup, ProfileMenuItem } from '../types';
import Session from '@/mythicaldash/Session';
import Permissions from '@/mythicaldash/Permissions';

interface DashboardCounts {
    user_count: number;
    locations_count: number;
    eggs_count: number;
    server_queue_count: number;
    servers_count: number;
    roles_count: number;
}
interface DashboardData { count: DashboardCounts; }

export function useAdminMenu(route: { path: string }, dashBoard: { value: DashboardData }) {
    const adminBaseUri = '/mc-admin';

    const menuGroups = ref<MenuGroup[]>([
        {
            title: 'Main Menu',
            items: [
                { name: 'Dashboard', path: `${adminBaseUri}`, icon: LayoutDashboard, active: route.path === `${adminBaseUri}`, visible: computed(() => Session.Permission.Has(Permissions.ADMIN_DASHBOARD_VIEW))},
                { name: 'Health', path: `${adminBaseUri}/health`, icon: HeartHandshakeIcon, active: route.path === `${adminBaseUri}/health`, visible: computed(() => Session.Permission.Has(Permissions.ADMIN_HEALTH_VIEW))},
            ],
        },
        {
            title: 'Management',
            items: [
                { name: 'Users', path: `${adminBaseUri}/users`, icon: Users, count: computed(() => dashBoard.value.count.user_count || 0), active: route.path === `${adminBaseUri}/users`, visible: computed(() => Session.Permission.Has(Permissions.ADMIN_USERS_LIST)) },
                { name: 'Locations', icon: PaperclipIcon, path: `${adminBaseUri}/locations`, active: route.path === `${adminBaseUri}/locations`, count: computed(() => dashBoard.value.count.locations_count || 0), visible: computed(() => Session.Permission.Has(Permissions.ADMIN_LOCATIONS_LIST)) },
                { name: 'Eggs & Nests', icon: EggIcon, count: computed(() => dashBoard.value.count.eggs_count || 0), active: route.path === `${adminBaseUri}/egg-categories` || route.path === `${adminBaseUri}/eggs`, visible: computed(() => Session.Permission.Has(Permissions.ADMIN_EGG_LIST) || Session.Permission.Has(Permissions.ADMIN_NESTS_LIST)),
                    subMenu: [
                        { name: 'Nests (Categories)', path: `${adminBaseUri}/egg-categories`, icon: EggIcon, visible: computed(() => Session.Permission.Has(Permissions.ADMIN_EGG_LIST)) },
                        { name: 'Eggs', path: `${adminBaseUri}/eggs`, icon: EggIcon, visible: computed(() => Session.Permission.Has(Permissions.ADMIN_EGG_LIST)) },
                    ],
                },
                { name: 'Roles', path: `${adminBaseUri}/roles`, icon: Shield, count: computed(() => dashBoard.value.count.roles_count || 0), active: route.path === `${adminBaseUri}/roles`, visible: computed(() => Session.Permission.Has(Permissions.ADMIN_ROLES_LIST)) },
            ],
        },
        {
            title: 'Servers',
            items: [
                { name: 'Server Queue', icon: ServerCrash, active: route.path === `${adminBaseUri}/server-queue`, count: computed(() => dashBoard.value.count.server_queue_count || 0), visible: computed(() => Session.Permission.Has(Permissions.ADMIN_SERVER_QUEUE_LIST)) },
                { name: 'Servers', icon: Server, active: route.path === `${adminBaseUri}/servers`, count: computed(() => dashBoard.value.count.servers_count || 0), path: `${adminBaseUri}/servers`, visible: computed(() => Session.Permission.Has(Permissions.ADMIN_SERVERS_LIST)) },
            ],
        },
        {
            title: 'Advanced',
            items: [
                { name: 'Settings', path: `${adminBaseUri}/settings`, icon: SettingsIcon, active: route.path === `${adminBaseUri}/settings`, visible: computed(() => Session.Permission.Has(Permissions.ADMIN_SETTINGS_VIEW)) },
            ],
        },
    ]);

    const profileMenu: ProfileMenuItem[] = [
        { name: 'Profile', path: '/account' },
        { name: 'Exit Admin', path: '/dashboard' },
        { name: 'Sign out', path: '/auth/logout' },
    ];

    return { menuGroups, profileMenu };
}