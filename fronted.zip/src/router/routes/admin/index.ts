import type { RouteRecordRaw } from 'vue-router';
import locationRoutes from './locations.ts';
import eggRoutes from './eggs.ts';
import eggCategoryRoutes from './egg-categories.ts';
import userRoutes from './users.ts';
import queueRoutes from './queue.ts';
import settingsRoutes from './settings.ts';
import serversRoutes from './servers.ts';
import rolesRoutes from './roles.ts';
import Session from '@/mythicaldash/Session';
import Permissions from '@/mythicaldash/Permissions';

// Main admin dashboard routes
const mainAdminRoutes: RouteRecordRaw[] = [
    {
        path: '/mc-admin',
        name: 'Admin Home',
        component: () => import('@/views/admin/Home.vue'),
        meta: {
            requiresAuth: true,
            requiresAdmin: true,
        },
        beforeEnter: (to, from, next) => {
            if (Session.hasOrRedirectToErrorPage(Permissions.ADMIN_DASHBOARD_VIEW)) {
                next();
            } else {
                next('/errors/403');
            }
        },
    },
    {
        path: '/mc-admin/health',
        name: 'Health',
        component: () => import('@/views/admin/health/Health.vue'),
        meta: {
            requiresAuth: true,
            requiresAdmin: true,
        },
        beforeEnter: (to, from, next) => {
            if (Session.hasOrRedirectToErrorPage(Permissions.ADMIN_HEALTH_VIEW)) {
                next();
            } else {
                next('/errors/403');
            }
        },
    },
];

// Combine all admin routes
const adminRoutes: RouteRecordRaw[] = [
    ...mainAdminRoutes,
    ...locationRoutes,
    ...eggRoutes,
    ...eggCategoryRoutes,
    ...userRoutes,
    ...settingsRoutes,
    ...queueRoutes,
    ...serversRoutes,
    ...rolesRoutes,
];

export default adminRoutes;