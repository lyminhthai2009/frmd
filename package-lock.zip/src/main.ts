// --- START OF FILE src/main.ts ---

import './assets/main.css';

import { createApp } from 'vue';
import { createPinia } from 'pinia';
import App from './App.vue';
import router from './router';
import VueSweetalert2 from 'vue-sweetalert2';
import './assets/sweetalert2.css';

// Import performance optimizations
import { initializePerformanceOptimizations, updatePerformanceSettings } from '@/utils/performance';

const app = createApp(App);

app.use(createPinia());
app.use(router);
app.use(VueSweetalert2);

// Initialize performance optimizations early
try {
    initializePerformanceOptimizations();

    // Set up a watcher for performance settings changes in localStorage
    if (typeof window !== 'undefined') {
        window.addEventListener('storage', (e) => {
            if (e.key === 'ui-settings') {
                updatePerformanceSettings();
            }
        });
    }
} catch (error) {
    console.warn('Failed to initialize performance optimizations:', error);
}

app.mount('#app');