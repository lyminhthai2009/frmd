// --- START OF FILE src/stores/settings.ts ---

import { defineStore } from 'pinia';
import { ref } from 'vue';
import router from '@/router'; // Import router for navigation

interface SettingsResponse {
    success: boolean;
    message?: string;
    error_code?: string;
    settings: Record<string, string>;
    core: Record<string, string>;
}

interface CachedSettings {
    value: Record<string, string>;
    timestamp: number;
}

export const useSettingsStore = defineStore('settings', () => {
    const settings = ref<Record<string, string>>({});
    const isInitialized = ref(false);
    let initPromise: Promise<void> | null = null;
    const CACHE_DURATION = 30 * 60 * 1000; // 30 minutes in milliseconds
    const CACHE_KEY = 'mythicaldash_settings_cache';

    function loadFromCache(): boolean {
        const cached = localStorage.getItem(CACHE_KEY);
        if (!cached) return false;

        try {
            const { value, timestamp }: CachedSettings = JSON.parse(cached);
            const now = Date.now();

            if (now - timestamp < CACHE_DURATION) {
                settings.value = value;
                isInitialized.value = true;
                return true;
            }

            localStorage.removeItem(CACHE_KEY);
            return false;
        } catch {
            return false;
        }
    }

    function saveToCache(settingsData: Record<string, string>) {
        const cache: CachedSettings = {
            value: settingsData,
            timestamp: Date.now(),
        };
        localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
    }

    async function fetchSettings(): Promise<SettingsResponse> {
        const response = await fetch('/api/system/settings');

        if (!response.ok) {
            if (response.status >= 500) {
                router.push({ name: 'ServerError' });
            }
            throw new Error(`Server error: ${response.status}`);
        }

        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            router.push({ name: 'ServerError' });
            throw new Error(`Invalid response type: ${contentType}`);
        }

        const data = await response.json();

        if (!data.success) {
            if (data.error_code === 'LICENSE_INVALID') {
                router.push({ name: 'Forbidden' }); 
            } else {
                router.push({ name: 'ServerError' });
            }
            throw new Error(data.message || 'Failed to fetch settings');
        }
        return data;
    }

    async function initialize() {
        if (initPromise) return initPromise;
        if (isInitialized.value) return;

        initPromise = (async () => {
            if (loadFromCache()) {
                initPromise = null;
                return;
            }

            try {
                const data = await fetchSettings();
                settings.value = { ...data.settings, ...data.core };
                saveToCache(settings.value);

                Object.entries(settings.value).forEach(([key, value]) => {
                    localStorage.setItem(key, JSON.stringify(value));
                });

                isInitialized.value = true;
            } catch (error) {
                console.error('Failed to initialize settings:', error);
                // In case of error, we throw it to let the caller handle it.
                // The router push in fetchSettings will handle navigation.
                throw error; 
            } finally {
                initPromise = null;
            }
        })();
        
        return initPromise;
    }


    function getSetting(key: string): string {
        if (settings.value[key] !== undefined) {
            return settings.value[key];
        }

        const item = localStorage.getItem(key);
        if (item) {
            try {
                const value = JSON.parse(item);
                settings.value[key] = value;
                return value;
            } catch {
                return item;
            }
        }

        if (!isInitialized.value) {
            initialize();
        }

        return '';
    }

    function getBooleanSetting(key: string): boolean {
        const value = getSetting(key);
        return value === 'true';
    }

    async function refreshSettings() {
        try {
            const data = await fetchSettings();
            settings.value = { ...data.settings, ...data.core };
            saveToCache(settings.value);

            Object.entries(settings.value).forEach(([key, value]) => {
                localStorage.setItem(key, JSON.stringify(value));
            });
        } catch (error) {
            console.error('Failed to refresh settings:', error);
            throw error;
        }
    }

    return {
        settings,
        isInitialized,
        initialize,
        getSetting,
        getBooleanSetting,
        refreshSettings,
    };
});