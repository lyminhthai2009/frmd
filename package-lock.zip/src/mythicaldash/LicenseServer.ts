import { useSettingsStore } from '@/stores/settings';

interface LicenseResponse {
    code: number;
    success: boolean;
    message: string;
    error?: string | null;
    valid: boolean;
    core?: {
        debug_os: string;
        debug_os_kernel: string;
        debug_name: string;
        debug_debug: boolean;
        debug_version: string;
        debug_telemetry: boolean;
        debug: {
            useRedis: boolean;
            rateLimit: {
                enabled: boolean;
                limit: number;
            };
        };
    };
}

interface LicenseCache {
    valid: boolean;
    timestamp: number;
}

export class LicenseServer {
    private static readonly CACHE_KEY = 'license';
    private static readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes in milliseconds

    /**
     * Validates the license with the server and caches the result
     */
    public static async validateLicense(type: string): Promise<boolean> {
        try {
            // Check cache first
            const cachedLicense = this.getLicenseFromCache();
            if (cachedLicense !== null) {
                return cachedLicense.valid;
            }

            // If no cache or expired, fetch from server
            const response = await fetch(`/api/system/license/${type}`);
            const data: LicenseResponse = await response.json();

            // Cache the result - use the 'valid' field from the response
            this.cacheLicense(data.valid);

            return data.valid;
        } catch (error) {
            console.error('License validation failed:', error);
            return false;
        }
    }

    /**
     * Gets the license status from cache
     */
    private static getLicenseFromCache(): LicenseCache | null {
        try {
            const cached = localStorage.getItem(this.CACHE_KEY);
            if (!cached) return null;

            const license: LicenseCache = JSON.parse(cached);
            const now = Date.now();

            // Check if cache is expired
            if (now - license.timestamp > this.CACHE_DURATION) {
                localStorage.removeItem(this.CACHE_KEY);
                return null;
            }

            return license;
        } catch {
            return null;
        }
    }

    /**
     * Caches the license status
     */
    private static cacheLicense(isValid: boolean): void {
        const license: LicenseCache = {
            valid: isValid,
            timestamp: Date.now(),
        };
        localStorage.setItem(this.CACHE_KEY, JSON.stringify(license));
    }

    /**
     * Checks if the license is valid (from cache or server)
     */
    public static async isLicenseValid(type: string): Promise<boolean> {
        const Settings = useSettingsStore();
        const appName = Settings.getSetting('app_name');
        console.log('Checking license for ' + appName);

        const isValid = await this.validateLicense(type);
        console.log('License is valid:', isValid);
        return isValid;
    }

    /**
     * Clears the license cache
     */
    public static clearCache(): void {
        localStorage.removeItem(this.CACHE_KEY);
    }

    /**
     * Forces a refresh of the license status
     */
    public static async refreshLicense(type: string): Promise<boolean> {
        this.clearCache();
        return await this.validateLicense(type);
    }
}
