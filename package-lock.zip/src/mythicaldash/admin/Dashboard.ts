// --- START OF FILE src/mythicaldash/admin/Dashboard.ts ---
import type { DashboardResponse } from '@/types/dashboard';
import MythicalDash from '../MythicalDash';

class Dashboard {
    /**
     * Get the dashboard data
     *
     * @returns {Promise<DashboardResponse>}
     */
    public static async get(): Promise<DashboardResponse> {
        const response = await fetch('/api/admin', {
            method: 'GET',
            headers: MythicalDash.createHeaders(),
        });
        return (await response.json()) as DashboardResponse;
    }
}

export default Dashboard;