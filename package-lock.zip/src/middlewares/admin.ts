import type { RouteLocationNormalized, NavigationGuardNext } from 'vue-router';
import Session from '@/mythicaldash/Session';

// Check if user is admin
export function isAdmin(): boolean {
    // SECURITY FIX: Switched from localStorage to Session.getInfo to prevent client-side manipulation.
    // The user's role is now based on the secure session data.
    const userRole = Session.getInfo('role');
    const adminRoles = ['2', '3', '4', '5', '6', '7', '8'];
    return adminRoles.includes(userRole || '');
}

// Admin middleware
export function adminMiddleware(to: RouteLocationNormalized, from: RouteLocationNormalized, next: NavigationGuardNext) {
    if (!isAdmin()) {
        return next({ name: 'Dashboard' });
    }
    return next();
}
