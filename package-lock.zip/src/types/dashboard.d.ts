// --- START OF FILE src/types/dashboard.d.ts ---
export interface DashboardCounts {
    user_count: number;
    servers_count: number;
    locations_count: number;
    eggs_count: number;
    server_queue_count: number;
    roles_count: number;
    tickets_count: number;
    // Add other counts as needed from your API response
    departments_count: number;
    announcements_count: number;
    mail_templates_count: number;
    settings_count: number;
    addons_count: number;
    plugins_count: number;
    redeem_codes_count: number;
}

export interface GitHubOwner {
    login: string;
    avatar_url: string;
}

export interface GitHubData {
    name: string;
    description: string;
    owner: GitHubOwner;
    stargazers_count: number;
    forks_count: number;
    open_issues_count: number;
    html_url: string;
}

export interface Activity {
    id: number;
    user: string;
    action: string;
    ip_address: string;
    date: string;
    context: string;
}

export interface AnalyticsData {
    new_users_24h: number;
    new_servers_24h: number;
    total_servers: number;
    pending_servers: number;
    new_tickets_24h: number;
    open_tickets: number;
    resource_usage: {
        memory: number;
        disk: number;
        server_count: number;
    };
    hourly_activity: number[];
}

export interface DashboardResponse {
    success: boolean;
    count: DashboardCounts;
    core?: {
        github_data: GitHubData;
        logs: string[];
    };
    etc?: {
        activity: Activity[];
    };
    analytics?: AnalyticsData;
}