// --- START OF FILE src/views/client/auth/Logout.vue ---

<template>
    <div class="flex flex-col items-center justify-center min-h-screen bg-gray-900">
        <div class="text-center">
            <div class="mb-4">
                <svg
                    class="animate-spin h-12 w-12 text-purple-500 mx-auto"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                >
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path
                        class="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                </svg>
            </div>
            <h1 class="text-3xl font-bold text-white mb-2">Logging out...</h1>
            <p class="text-gray-400">Please wait while we securely log you out</p>
        </div>
    </div>
</template>

<script setup lang="ts">
import { onMounted } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

const clearData = async () => {
    // Keys related to user session that should be removed on logout
    const sessionKeys = [
        'user_token',
        'user_permissions',
        'username',
        'email',
        'first_name',
        'last_name',
        'avatar',
        'role',
        'role_name',
        'support_pin',
        'verified',
        '2fa_enabled',
        // Add any other session-specific keys here
    ];

    // Selectively remove session items from localStorage
    sessionKeys.forEach(key => localStorage.removeItem(key));
    
    // Clear sessionStorage completely as it's meant for a single session
    sessionStorage.clear();

    // Clear session cookie
    document.cookie = 'user_token=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/';

    // Clear cache, IndexedDB, etc. (these are good to clear for security)
    const promises = [];
    if (window.indexedDB && window.indexedDB.databases) {
        const indexedDBPromise = window.indexedDB.databases().then((dbs) => {
            return Promise.all(
                dbs.map((db) => {
                    if (typeof db.name === 'string') {
                        return new Promise<void>((resolve, reject) => {
                            const req = window.indexedDB.deleteDatabase(db.name as string);
                            req.onsuccess = () => resolve();
                            req.onerror = () => reject(req.error);
                        });
                    }
                    return Promise.resolve();
                }),
            );
        });
        promises.push(indexedDBPromise);
    }
    if ('caches' in window) {
        const cachePromise = caches.keys().then((names) => {
            return Promise.all(names.map((name) => caches.delete(name)));
        });
        promises.push(cachePromise);
    }
    if ('serviceWorker' in navigator) {
        const serviceWorkerPromise = navigator.serviceWorker.getRegistrations().then((registrations) => {
            return Promise.all(registrations.map((registration) => registration.unregister()));
        });
        promises.push(serviceWorkerPromise);
    }

    await Promise.allSettled(promises);
};

onMounted(async () => {
    await clearData();
    router.push('/auth/login');
});
</script>