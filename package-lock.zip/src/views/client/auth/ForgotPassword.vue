<script setup lang="ts">
import { ref, reactive } from 'vue';
import Layout from '@/components/client/Layout.vue';
import FormCard from '@/components/client/Auth/FormCard.vue';
import FormInput from '@/components/client/Auth/FormInput.vue';
import { useSound } from '@vueuse/sound';
import failedAlertSfx from '@/assets/sounds/error.mp3';
import successAlertSfx from '@/assets/sounds/success.mp3';
import Swal from 'sweetalert2';
import Turnstile from 'vue-turnstile';
import { useSettingsStore } from '@/stores/settings';
const Settings = useSettingsStore();
import { useRouter } from 'vue-router';
import Auth from '@/mythicaldash/Auth';
import { MythicalDOM } from '@/mythicaldash/MythicalDOM';
const { play: playError } = useSound(failedAlertSfx);
const { play: playSuccess } = useSound(successAlertSfx);
const router = useRouter();

const loading = ref(false);
const form = reactive({
    email: '',
    turnstileResponse: '',
});

MythicalDOM.setPageTitle('Forgot Password');

const handleSubmit = async () => {
    loading.value = true;
    const response = await Auth.forgotPassword(form.email, form.turnstileResponse);
    try {
        if (!response.success) {
            const error_code = response.error_code as string;
            const errorMessages: { [key: string]: string } = {
                'TURNSTILE_FAILED': 'You have been blocked by Cloudflare Turnstile',
                'EMAIL_DOES_NOT_EXIST': 'Email not found',
                'FAILED_TO_SEND_EMAIL': 'An error occurred. Please try again later',
                'PROXY_DETECTED': 'You are using a vpn or a proxy!',
            };

            const errorMessage = errorMessages[error_code] || 'An error occurred. Please try again later';
            
            playError();
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                footer: 'Please contact support for assistance',
                showConfirmButton: true,
            });
            loading.value = false;
        } else {
            playSuccess();
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'Password reset link sent',
                footer: 'Check your email!',
                showConfirmButton: true,
            });
            setTimeout(() => {
                router.push('/auth/login');
            }, 1500);
        }
    } catch (error) {
        console.error('Forgot password failed:', error);
    } finally {
        loading.value = false;
    }
};
</script>

<template>
    <Layout>
        <FormCard title="Reset your password" @submit="handleSubmit">
            <FormInput
                id="email"
                label="Email"
                v-model="form.email"
                type="email"
                placeholder="Enter your email"
                required
            />
            <div
                v-if="Settings.getSetting('turnstile_enabled') == 'true'"
                style="display: flex; justify-content: center; margin-top: 20px"
            >
                <Turnstile :site-key="Settings.getSetting('turnstile_key_pub')" v-model="form.turnstileResponse" />
            </div>
            <button
                type="submit"
                class="w-full mt-6 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
                :disabled="loading"
            >
                {{ loading ? 'Sending reset link...' : 'Reset Password' }}
            </button>

            <p class="mt-4 text-center text-sm text-gray-400">
                Remembered your password?
                <router-link to="/auth/login" class="text-purple-400 hover:text-purple-300">
                    Login
                </router-link>
            </p>
        </FormCard>
    </Layout>
</template>