<script setup lang="ts">
import { ref, reactive } from 'vue';
import Layout from '@/components/client/Layout.vue';
import FormCard from '@/components/client/Auth/FormCard.vue';
import FormInput from '@/components/client/Auth/FormInput.vue';
import { useRouter } from 'vue-router';
import Turnstile from 'vue-turnstile';
import { useSettingsStore } from '@/stores/settings';
const Settings = useSettingsStore();
import { MythicalDOM } from '@/mythicaldash/MythicalDOM';

const router = useRouter();

MythicalDOM.setPageTitle('Single Sign-On');

const loading = ref(false);
const form = reactive({
    name: '',
    turnstileResponse: '',
});

const handleSubmit = async () => {
    loading.value = true;
    try {
        localStorage.setItem('domain_name', form.name);
        await new Promise((resolve) => setTimeout(resolve, 2000));
        router.push('/auth/login');
    } catch (error) {
        console.error(error);
    } finally {
        loading.value = false;
    }
};
</script>
<template>
    <Layout>
        <FormCard title="Single Sign-On" @submit="handleSubmit">
            <FormInput
                id="text"
                label="Domain name"
                v-model="form.name"
                placeholder="Organization Name"
                required
            />
            <p class="mt-4 text-center text-sm text-gray-400">
                This is an Enterprise feature. Please make sure you enter your company name or domain name.
            </p>
            <div
                v-if="Settings.getSetting('turnstile_enabled') == 'true'"
                style="display: flex; justify-content: center; margin-top: 20px"
            >
                <Turnstile :site-key="Settings.getSetting('turnstile_key_pub')" v-model="form.turnstileResponse" />
            </div>
            <button
                type="submit"
                class="w-full mt-6 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
                :disabled="loading"
            >
                {{ loading ? 'Redirecting...' : 'Login' }}
            </button>

            <p class="mt-4 text-center text-sm text-gray-400">
                Not a organization or domain?
                <router-link to="/auth/login" class="text-purple-400 hover:text-purple-300">
                    Login
                </router-link>
            </p>
        </FormCard>
    </Layout>
</template>