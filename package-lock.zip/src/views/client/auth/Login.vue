<script setup lang="ts">
import { ref, reactive } from 'vue';
import Layout from '@/components/client/Layout.vue';
import FormCard from '@/components/client/Auth/FormCard.vue';
import FormInput from '@/components/client/Auth/FormInput.vue';
import Swal from 'sweetalert2';
import { useRouter } from 'vue-router';
import Turnstile from 'vue-turnstile';
import { useSettingsStore } from '@/stores/settings';
const Settings = useSettingsStore();
import { useSound } from '@vueuse/sound';
import failedAlertSfx from '@/assets/sounds/error.mp3';
import successAlertSfx from '@/assets/sounds/success.mp3';
import Auth from '@/mythicaldash/Auth';
import { MythicalDOM } from '@/mythicaldash/MythicalDOM';

const { play: playError } = useSound(failedAlertSfx);
const { play: playSuccess } = useSound(successAlertSfx);
const router = useRouter();
localStorage.clear();
sessionStorage.clear();
MythicalDOM.setPageTitle('Login');

const loading = ref(false);
const form = reactive({
    email: '',
    password: '',
    turnstileResponse: '',
});

const errorMessages = {
    TURNSTILE_FAILED: 'You have been blocked by Cloudflare Turnstile',
    INVALID_CREDENTIALS: 'Invalid credentials',
    ACCOUNT_NOT_VERIFIED: 'Your email is not verified yet',
    ACCOUNT_BANNED: 'Your account was permanently banned',
    ACCOUNT_DELETED: 'Your account was deleted either by you or an admin',
    PTERODACTYL_USER_NOT_FOUND: 'Pterodactyl user not found.',
    PTERODACTYL_ERROR: 'Failed to register user in Pterodactyl panel',
    PTERODACTYL_NOT_ENABLED: 'Pterodactyl is not enabled',
    PROXY_DETECTED: 'You are using a vpn or a proxy!',
};

const handleSubmit = async () => {
    try {
        loading.value = true;
        const response = await Auth.login(form.email, form.password, form.turnstileResponse);
        if (!response.success) {
            const error_code = response.error_code as keyof typeof errorMessages;
            if (errorMessages[error_code]) {
                playError();
                Swal.fire({
                    icon: 'error',
                    title: 'Login Error',
                    text: errorMessages[error_code],
                    footer: 'Please contact support for assistance',
                    showConfirmButton: true,
                });
                loading.value = false;
                return;
            } else {
                playError();
                Swal.fire({
                    icon: 'error',
                    title: 'Login Error',
                    text: response.message,
                    footer: 'Please contact support for assistance',
                    showConfirmButton: true,
                });
                loading.value = false;
                return;
            }
        }

        playSuccess();
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: 'You have successfully logged in',
            footer: 'Welcome back!',
            showConfirmButton: true,
        });
        loading.value = false;
        setTimeout(() => {
            router.push('/');
        }, 1500);
    } catch (error) {
        console.error('Login failed:', error);
        loading.value = false;
    }
};
</script>
<template>
    <Layout>
        <FormCard title="Login to your Account" @submit="handleSubmit">
            <FormInput
                id="email"
                label="Email or Username"
                v-model="form.email"
                placeholder="Enter your email or username"
                required
            />
            <div class="flex items-center justify-between mb-2">
                <label class="block text-sm text-gray-400">Password</label>
                <router-link to="/auth/forgot-password" class="text-sm text-purple-400 hover:text-purple-300">
                    Forgot password?
                </router-link>
            </div>

            <FormInput id="password" type="password" v-model="form.password" placeholder="Enter your password" required />
            <div
                v-if="Settings.getSetting('turnstile_enabled') == 'true'"
                style="display: flex; justify-content: center; margin-top: 20px"
            >
                <Turnstile :site-key="Settings.getSetting('turnstile_key_pub')" v-model="form.turnstileResponse" />
            </div>
            <button
                type="submit"
                class="w-full mt-6 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
                :disabled="loading"
            >
                {{ loading ? 'Logging in...' : 'Login' }}
            </button>
            <p class="mt-4 text-center text-sm text-gray-400">
                Don't have an account?
                <router-link to="/auth/register" class="text-purple-400 hover:text-purple-300">
                    Register
                </router-link>
            </p>
        </FormCard>
    </Layout>
</template>