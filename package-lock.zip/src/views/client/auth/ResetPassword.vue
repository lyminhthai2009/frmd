<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue';
import Layout from '@/components/client/Layout.vue';
import FormCard from '@/components/client/Auth/FormCard.vue';
import FormInput from '@/components/client/Auth/FormInput.vue';
import { useSound } from '@vueuse/sound';
import failedAlertSfx from '@/assets/sounds/error.mp3';
import successAlertSfx from '@/assets/sounds/success.mp3';
import Swal from 'sweetalert2';
import Turnstile from 'vue-turnstile';
import { useSettingsStore } from '@/stores/settings';
const Settings = useSettingsStore();
import { useRouter } from 'vue-router';
import Auth from '@/mythicaldash/Auth';
import { MythicalDOM } from '@/mythicaldash/MythicalDOM';

const { play: playError } = useSound(failedAlertSfx);
const { play: playSuccess } = useSound(successAlertSfx);
const router = useRouter();

const loading = ref(false);
const form = reactive({
    password: '',
    confirmPassword: '',
    turnstileResponse: '',
});

MythicalDOM.setPageTitle('Reset Password');

const checkResetCode = async (code: string) => {
    try {
        const response = await Auth.isLoginVerifyTokenValid(code);
        if (!response.success) {
            location.href = '/auth/login?invalid_code';
        }
    } catch (error) {
        console.error('Error checking reset code:', error);
    }
};

onMounted(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const resetCode = urlParams.get('token');

    if (resetCode) {
        checkResetCode(resetCode);
    } else {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Missing reset code.',
            showConfirmButton: true,
        }).then(() => {
            router.push('/auth/login');
        });
    }
});

const handleSubmit = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const resetCode = urlParams.get('token');
    loading.value = true;

    try {
        const response = await Auth.resetPassword(
            form.confirmPassword,
            form.password,
            resetCode || '',
            form.turnstileResponse,
        );

        if (!response.success) {
            const error_code = response.error_code as string;
            const errorMessages: { [key: string]: string } = {
                'TURNSTILE_FAILED': 'You have been blocked by Cloudflare Turnstile',
                'PASSWORDS_DO_NOT_MATCH': 'Passwords do not match',
                'INVALID_CODE': 'Invalid reset code',
                'PROXY_DETECTED': 'You are using a vpn or a proxy!',
            };
            const errorMessage = errorMessages[error_code] || 'An error occurred. Please try again later';
            
            playError();
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                footer: 'Please contact support for assistance',
                showConfirmButton: true,
            });
        } else {
            playSuccess();
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'We have successfully reset your password',
                footer: 'Check your email!',
                showConfirmButton: true,
            });
            setTimeout(() => {
                router.push('/auth/login');
            }, 1500);
        }
    } catch (error) {
        console.error('Reset password failed:', error);
    } finally {
        loading.value = false;
    }
};
</script>

<template>
    <Layout>
        <FormCard title="Reset your password" @submit="handleSubmit">
            <FormInput
                id="password"
                label="New Password"
                v-model="form.password"
                type="password"
                placeholder="Enter your new password"
                required
            />
            <FormInput
                id="confirmPassword"
                label="Confirm Password"
                v-model="form.confirmPassword"
                type="password"
                placeholder="Confirm your new password"
                required
            />

            <button
                type="submit"
                class="w-full mt-6 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
                :disabled="loading"
            >
                {{ loading ? 'Applying changes...' : 'Reset Password' }}
            </button>

            <div
                v-if="Settings.getSetting('turnstile_enabled') == 'true'"
                style="display: flex; justify-content: center; margin-top: 20px"
            >
                <Turnstile :site-key="Settings.getSetting('turnstile_key_pub')" v-model="form.turnstileResponse" />
            </div>

            <p class="mt-4 text-center text-sm text-gray-400">
                Remembered your password?
                <router-link to="/auth/login" class="text-purple-400 hover:text-purple-300">
                    Login
                </router-link>
            </p>
        </FormCard>
    </Layout>
</template>