<script setup lang="ts">
import { computed } from 'vue';
import {
    ServerIcon,
    Gift as GiftIcon,
    Link as LinkIcon,
    Home as HomeIcon,
} from 'lucide-vue-next';
import { useSettingsStore } from '@/stores/settings';
import { useSkinSettings } from '@/composables/useSkinSettings';

const Settings = useSettingsStore();
const { sidebarSettings } = useSkinSettings();

const isCodeRedemptionEnabled = computed(() => Settings.getSetting('code_redemption_enabled') === 'true');
const isL4REnabled = computed(() => Settings.getSetting('l4r_enabled') === 'true');
const isServersEnabled = computed(() => Settings.getSetting('allow_servers') === 'true');

defineProps<{ isSidebarOpen: boolean; }>();

const isActiveRoute = (routes: string | string[]) => {
    return routes.includes(window.location.pathname);
};

interface MenuItem {
    name: string;
    icon: unknown;
    href?: string;
    active: boolean;
}

interface MenuSection {
    title: string;
    items: MenuItem[];
}

const menuSections = computed<MenuSection[]>(() => [
    {
        title: 'General',
        items: [
            { name: 'Dashboard', icon: HomeIcon, href: '/dashboard', active: isActiveRoute(['/dashboard']) },
            ...(isServersEnabled.value ? [{ name: 'Create Server', icon: ServerIcon, href: '/server/create', active: isActiveRoute(['/server/create']) }] : []),
        ],
    },
    {
        title: 'Earn',
        items: [
            ...(isCodeRedemptionEnabled.value ? [{ name: 'Code Redemption', icon: GiftIcon, href: '/earn/redeem', active: isActiveRoute(['/earn/redeem']) }] : []),
            ...(isL4REnabled.value ? [{ name: 'Link For Rewards', icon: LinkIcon, href: '/earn/links', active: isActiveRoute(['/earn/links']) }] : []),
        ].filter(item => item), // Filter out undefined items
    },
]);

const compactClass = computed(() => (sidebarSettings.compactMode ? 'compact' : ''));
</script>

<template>
    <aside
        :class="[
            'fixed top-0 left-0 h-full w-64 transform transition-all duration-300 ease-in-out z-50 lg:translate-x-0 lg:z-20',
            isSidebarOpen ? 'translate-x-0' : '-translate-x-full',
            sidebarSettings.glassEffect ? 'bg-[#0a0a0f]/90 backdrop-blur-md' : 'bg-[#0a0a0f]',
            sidebarSettings.borderGlow ? 'border-r border-[#2a2a3f]/30 shadow-lg shadow-indigo-500/5' : 'border-r border-[#2a2a3f]/20',
            compactClass,
        ]"
    >
        <div class="flex flex-col h-full pt-16">
            <div class="flex-1 overflow-y-auto scrollbar-thin scrollbar-track-transparent scrollbar-thumb-[#2a2a3f]/50">
                <nav :class="sidebarSettings.compactMode ? 'p-2' : 'p-4'">
                    <div
                        v-for="(section, index) in menuSections"
                        :key="index"
                        :class="sidebarSettings.compactMode ? 'mb-4' : 'mb-6'"
                    >
                        <template v-if="section.items.length > 0">
                            <div
                                v-if="sidebarSettings.showSectionDividers"
                                :class="[
                                    'text-xs uppercase tracking-wider text-gray-500 font-medium flex items-center gap-2',
                                    sidebarSettings.compactMode ? 'px-2 mb-1' : 'px-4 mb-2',
                                ]"
                            >
                                <div class="h-px flex-1 bg-gradient-to-r from-transparent via-[#2a2a3f]/30 to-transparent"></div>
                                <span class="px-2 text-xs">{{ section.title }}</span>
                                <div class="h-px flex-1 bg-gradient-to-r from-transparent via-[#2a2a3f]/30 to-transparent"></div>
                            </div>

                            <div class="space-y-1">
                                <RouterLink
                                    v-for="item in section.items"
                                    :key="item.name"
                                    :to="item.href || ''"
                                    :class="[
                                        'flex items-center gap-3 rounded-lg hover:bg-[#1a1a2e]/50 transition-all duration-200 group',
                                        sidebarSettings.compactMode ? 'px-2 py-1.5' : 'px-4 py-2.5',
                                        sidebarSettings.borderGlow && item.active ? 'shadow-md shadow-indigo-500/20' : '',
                                        item.active ? 'bg-indigo-500/10 text-indigo-400' : 'text-gray-400 hover:text-white',
                                    ]"
                                >
                                    <div
                                        :class="[
                                            'rounded-lg bg-[#1a1a2e]/50 flex items-center justify-center transition-all duration-200 group-hover:bg-indigo-500/10',
                                            sidebarSettings.compactMode ? 'w-6 h-6' : 'w-8 h-8',
                                        ]"
                                    >
                                        <component
                                            :is="item.icon"
                                            :class="sidebarSettings.compactMode ? 'w-3.5 h-3.5' : 'w-4 h-4'"
                                        />
                                    </div>
                                    <span :class="['font-medium', sidebarSettings.compactMode ? 'text-xs' : 'text-sm']">
                                        {{ item.name }}
                                    </span>
                                </RouterLink>
                            </div>
                        </template>
                    </div>
                </nav>
            </div>
        </div>
    </aside>
</template>