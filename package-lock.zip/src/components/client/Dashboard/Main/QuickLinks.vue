<template>
    <CardComponent
        cardTitle="Quick Links"
        cardDescription="Fast access to important areas"
    >
        <div class="quicklinks-container relative overflow-hidden">
            <!-- Background decoration -->
            <div class="absolute -top-20 -left-20 w-40 h-40 bg-indigo-500/5 rounded-full blur-2xl"></div>
            <div class="absolute -bottom-20 -right-20 w-40 h-40 bg-blue-500/5 rounded-full blur-2xl"></div>

            <div class="space-y-3 relative z-10">
                <div
                    v-for="(link, index) in quickLinks"
                    :key="link.name"
                    @click="navigateTo(link.href)"
                    class="quick-link flex items-center py-2.5 px-3.5 rounded-lg cursor-pointer hover:bg-gray-800/50 transition-all duration-200 backdrop-blur-sm border border-gray-700/20 hover:border-indigo-500/30"
                    :style="{ animationDelay: `${index * 0.1}s` }"
                >
                    <div
                        class="icon-container w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-600/20 to-blue-600/20 flex items-center justify-center mr-3 relative overflow-hidden"
                    >
                        <component :is="link.icon" class="w-5 h-5 text-indigo-400 relative z-10" />
                        <div class="icon-glow"></div>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-sm font-medium text-white group-hover:text-indigo-400 transition-colors duration-200">
                            {{ link.name }}
                        </h3>
                        <p class="text-xs text-gray-400">{{ link.description }}</p>
                    </div>
                    <div class="arrow-container">
                        <ChevronRightIcon class="w-4 h-4 text-gray-400 arrow-icon" />
                    </div>
                </div>
            </div>
        </div>
    </CardComponent>
</template>

<script setup lang="ts">
import CardComponent from '@/components/client/ui/Card/CardComponent.vue';
import { useRouter } from 'vue-router';
import {
    Settings as SettingsIcon,
    ChevronRight as ChevronRightIcon,
    Server as ServerIcon,
} from 'lucide-vue-next';
import { useSettingsStore } from '@/stores/settings';
import { computed } from 'vue';

const Settings = useSettingsStore();
const router = useRouter();

const isServersEnabled = computed(() => Settings.getSetting('allow_servers') === 'true');

const quickLinks = computed(() => [
    ...(isServersEnabled.value ? [
        {
            name: 'Create Server',
            description: 'Set up a new game server',
            href: '/server/create',
            icon: ServerIcon,
        }
    ] : []),
    {
        name: 'Account Settings',
        description: 'Update your account settings',
        href: '/account',
        icon: SettingsIcon,
    },
]);

const navigateTo = (path: string) => {
    router.push(path);
};
</script>

<style scoped>
.quick-link { animation: fadeInUp 0.5s ease forwards; opacity: 0; transform: translateY(10px); }
.quick-link:hover { transform: translateY(-1px); }
.icon-container { transition: all 0.3s ease; }
.quick-link:hover .icon-container { transform: scale(1.05); box-shadow: 0 0 15px rgba(79, 70, 229, 0.3); }
.icon-glow { position: absolute; inset: 0; background: radial-gradient(circle, rgba(99, 102, 241, 0.3) 0%, transparent 70%); opacity: 0; transition: opacity 0.3s ease; }
.quick-link:hover .icon-glow { opacity: 1; animation: pulse 2s infinite; }
.arrow-container { transition: transform 0.2s ease; }
.quick-link:hover .arrow-container { transform: translateX(3px); }
.arrow-icon { transition: color 0.2s ease; }
.quick-link:hover .arrow-icon { color: #818cf8; }
@keyframes fadeInUp { to { opacity: 1; transform: translateY(0); } }
@keyframes pulse { 0%, 100% { opacity: 0.5; } 50% { opacity: 0.8; } }
</style>