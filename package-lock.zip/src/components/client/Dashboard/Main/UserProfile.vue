<template>
    <CardComponent
        cardTitle="My Profile"
        cardDescription="Your account information"
    >
        <div class="flex items-center space-x-4 mb-4">
            <img
                :src="`${Session.getInfo('avatar')}?height=60&width=60`"
                alt="Profile"
                class="w-14 h-14 rounded-full border-2 border-indigo-500/50"
            />
            <div>
                <h3 class="text-lg font-semibold text-white">
                    {{ Session.getInfo('first_name') }} {{ Session.getInfo('last_name') }}
                </h3>
                <div
                    class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-500/20 text-indigo-400 mt-1"
                >
                    {{ Session.getInfo('role_real_name') }}
                </div>
            </div>
        </div>
        <div class="border-t border-gray-800 mt-4 pt-4">
            <button @click="goToAccount" class="text-sm text-indigo-400 hover:text-indigo-300 flex items-center w-full">
                <SettingsIcon class="w-4 h-4 mr-1" />
                Manage Account
                <ChevronRightIcon class="w-4 h-4 ml-auto" />
            </button>
        </div>
    </CardComponent>
</template>

<script setup lang="ts">
import CardComponent from '@/components/client/ui/Card/CardComponent.vue';
import Session from '@/mythicaldash/Session';
import { useRouter } from 'vue-router';
import { Settings as SettingsIcon, ChevronRight as ChevronRightIcon } from 'lucide-vue-next';

const router = useRouter();

const goToAccount = () => {
    router.push('/account');
};
</script>