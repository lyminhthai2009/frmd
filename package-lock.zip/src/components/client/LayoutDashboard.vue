<script setup lang="ts">
import { ref, onMounted, onUnmounted, computed, watch } from 'vue';
import { useRouter } from 'vue-router';
import LoadingScreen from '@/components/client/ui/LoadingScreen.vue';
import TopNavBar from '@/components/client/layout/TopNavBar.vue';
import Sidebar from '@/components/client/layout/Sidebar.vue';
import SearchModal from '@/components/client/layout/SearchModal.vue';
import ProfileDropdown from '@/components/client/layout/ProfileDropdown.vue';
import { SettingsIcon, UserIcon, UsersIcon } from 'lucide-vue-next';
import Session from '@/mythicaldash/Session';
import StorageMonitor from '@/mythicaldash/StorageMonitor';
import { LicenseServer } from '@/mythicaldash/LicenseServer';
import Permissions from '@/mythicaldash/Permissions';

new StorageMonitor();

const router = useRouter();

if (!Session.isSessionValid()) {
    router.push('/auth/login');
}

try {
    Session.startSession();
} catch (error) {
    console.error('Session failed:', error);
}

const loading = ref(true);
const isSidebarOpen = ref(false);
const isSearchOpen = ref(false);
const isProfileOpen = ref(false);

// Toggle functions
const toggleSidebar = () => isSidebarOpen.value = !isSidebarOpen.value;
const closeSidebar = () => isSidebarOpen.value = false;
const toggleSearch = () => isSearchOpen.value = true;
const closeSearch = () => isSearchOpen.value = false;
const toggleProfile = () => isProfileOpen.value = !isProfileOpen.value;
const closeDropdowns = () => isProfileOpen.value = false;

const navigateToResult = (href: string) => {
    closeSearch();
    router.push(href);
};

// Event handlers
const handleClickOutside = (event: MouseEvent) => {
    const target = event.target as HTMLElement | null;
    if (target && !target.closest('.dropdown') && !target.closest('button')) {
        closeDropdowns();
    }
};

const handleKeydown = (event: KeyboardEvent) => {
    if (event.key === 'Escape') {
        closeSearch();
        closeDropdowns();
        closeSidebar();
    }
    if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
        event.preventDefault();
        toggleSearch();
    }
};

const userBackground = ref('');

watch(
    () => Session.getInfo('background'),
    (newBackground) => {
        userBackground.value = newBackground || '';
    },
    { immediate: true }
);

const pageBackgroundStyle = computed(() => {
    if (!userBackground.value) return {};
    return {
        backgroundImage: `linear-gradient(135deg, rgba(3, 3, 5, 0.85) 0%, rgba(10, 10, 21, 0.85) 50%, rgba(3, 3, 5, 0.85) 100%), url('${userBackground.value}')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        backgroundAttachment: 'fixed',
    };
});

// Profile Menu
const profileMenu = computed(() => {
    const menu = [{ name: 'Settings', icon: SettingsIcon, href: '/account' }];
    if (Session.hasPermission(Permissions.ADMIN_DASHBOARD_VIEW)) {
        menu.push({ name: 'Admin Area', icon: UsersIcon, href: '/mc-admin' });
    }
    return menu;
});

const userInfo = computed(() => ({
    firstName: Session.getInfo('first_name'),
    lastName: Session.getInfo('last_name'),
    roleName: (Session.getInfo('role_real_name') || 'User').charAt(0).toUpperCase() + (Session.getInfo('role_real_name') || 'User').slice(1),
    email: Session.getInfo('email'),
    avatar: Session.getInfo('avatar'),
    background: Session.getInfo('background'), // <-- DÒNG NÀY ĐƯỢC THÊM VÀO
}));

const showFooter = ref(true);

onMounted(async () => {
    document.addEventListener('click', handleClickOutside);
    document.addEventListener('keydown', handleKeydown);

    if (sessionStorage.getItem('firstLoad') === null) {
        loading.value = true;
        setTimeout(() => {
            loading.value = false;
            sessionStorage.setItem('firstLoad', 'false');
        }, 2000);
    } else {
        loading.value = false;
    }
    
    try {
        const isValid = await LicenseServer.isLicenseValid('branding-removal');
        showFooter.value = !isValid;
    } catch (error) {
        console.error('Error checking license:', error);
        showFooter.value = true;
    }
});

onUnmounted(() => {
    document.removeEventListener('click', handleClickOutside);
    document.removeEventListener('keydown', handleKeydown);
});
</script>

<template>
    <div class="min-h-screen bg-[#030305] relative overflow-hidden" :style="pageBackgroundStyle">
        <!-- Background elements -->
        <div
            class="absolute inset-0"
            :class="
                userBackground
                    ? 'bg-gradient-to-b from-black/30 via-black/20 to-black/30'
                    : 'bg-gradient-to-b from-[#030305] via-[#0a0a15] to-[#030305]'
            "
        >
            <div class="stars" :class="{ 'opacity-50': userBackground }"></div>
            <div class="grid-overlay" :class="{ 'opacity-30': userBackground }"></div>
            <div class="glow-effects" :class="{ 'opacity-50': userBackground }"></div>
        </div>

        <!-- Content wrapper -->
        <div class="relative z-10 min-h-screen">
            <LoadingScreen v-if="loading" />

            <template v-if="!loading">
                <!-- Backdrop for mobile sidebar -->
                <div
                    v-if="isSidebarOpen"
                    class="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 lg:hidden"
                    @click="closeSidebar"
                ></div>

                <TopNavBar
                    :isSidebarOpen="isSidebarOpen"
                    @toggle-sidebar="toggleSidebar"
                    @toggle-search="toggleSearch"
                    @toggle-profile="toggleProfile"
                    class="bg-[#050508]/90 backdrop-blur-md border-b border-[#1a1a2f]/30"
                />

                <Sidebar
                    :isSidebarOpen="isSidebarOpen"
                    class="bg-[#050508]/95 backdrop-blur-md border-r border-[#1a1a2f]/30"
                />

                <!-- Main Content -->
                <main class="pt-16 lg:pl-64 min-h-screen relative">
                    <div class="p-4 md:p-6 max-w-7xl mx-auto">
                        <slot></slot>
                    </div>
                </main>

                <SearchModal
                    :isSearchOpen="isSearchOpen"
                    @close="closeSearch"
                    @navigate="navigateToResult"
                    class="bg-[#050508]/95 backdrop-blur-lg border border-[#1a1a2f]/30"
                />

                <ProfileDropdown
                    :isOpen="isProfileOpen"
                    :profileMenu="profileMenu"
                    :userInfo="userInfo"
                    class="bg-[#050508]/95 backdrop-blur-lg border border-[#1a1a2f]/30"
                />

                <!-- Footer -->
                <footer v-if="showFooter" class="relative z-10 py-4 px-6 text-center text-sm text-gray-500">
                    <a href="https://mythical.systems" class="hover:text-indigo-400 transition-colors">
                        MythicalSystems
                    </a>
                    <p>2020 - {{ new Date().getFullYear() }}</p>
                </footer>
            </template>
        </div>
    </div>
</template>

<style scoped>
.stars {
    position: absolute; inset: 0;
    background-image:
        radial-gradient(1px 1px at 20% 30%, rgba(255, 255, 255, 0.2) 0%, transparent 100%),
        radial-gradient(1px 1px at 40% 70%, rgba(255, 255, 255, 0.15) 0%, transparent 100%),
        radial-gradient(1px 1px at 60% 40%, rgba(255, 255, 255, 0.2) 0%, transparent 100%),
        radial-gradient(2px 2px at 80% 10%, rgba(255, 255, 255, 0.15) 0%, transparent 100%);
    background-size: 250px 250px, 200px 200px, 300px 300px, 350px 350px;
    animation: twinkle 10s infinite;
}
.grid-overlay {
    position: absolute; inset: 0;
    background-image:
        linear-gradient(to right, rgba(42, 42, 63, 0.07) 1px, transparent 1px),
        linear-gradient(to bottom, rgba(42, 42, 63, 0.07) 1px, transparent 1px);
    background-size: 50px 50px;
    mask-image: linear-gradient(to bottom, transparent, rgba(0, 0, 0, 0.4));
}
.glow-effects {
    position: absolute; inset: 0;
    background:
        radial-gradient(circle at 20% 20%, rgba(99, 102, 241, 0.03) 0%, transparent 50%),
        radial-gradient(circle at 80% 80%, rgba(99, 102, 241, 0.03) 0%, transparent 50%);
    pointer-events: none;
}
@keyframes twinkle { 0%, 100% { opacity: 0.3; } 50% { opacity: 0.5; } }
@media (max-width: 768px) { .grid-overlay { background-size: 30px 30px; } }
</style>