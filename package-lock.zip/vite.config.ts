// --- START OF FILE vite.config.ts ---

import { fileURLToPath, URL } from 'node:url';

import { defineConfig, loadEnv } from 'vite';
import vue from '@vitejs/plugin-vue';
import vueJsx from '@vitejs/plugin-vue-jsx';
import vueDevTools from 'vite-plugin-vue-devtools';
import oxlintPlugin from 'vite-plugin-oxlint';
import tailwindcss from '@tailwindcss/vite';
import { visualizer } from 'rollup-plugin-visualizer';

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, process.cwd(), '');

    return {
        plugins: [
            vue(),
            vueJsx(),
            vueDevTools(),
            tailwindcss(),
            oxlintPlugin(),
            // Only run visualizer if ANALYZE env var is set
            env.ANALYZE
                ? visualizer({
                      emitFile: true,
                      filename: 'build-stats.html',
                      open: true,
                      sourcemap: true,
                  })
                : undefined,
        ],
        resolve: {
            alias: {
                '@': fileURLToPath(new URL('./src', import.meta.url)),
            },
        },
        server: {
            host: '0.0.0.0',
            proxy: {
                '/api': {
                    target: env.VITE_API_TARGET || 'http://localhost:6000',
                    changeOrigin: true,
                    secure: false,
                    rewrite: (path) => path,
                },
            },
        },
        build: {
            // Disable sourcemaps in production for security and performance
            sourcemap: mode !== 'production',
            chunkSizeWarningLimit: 120000,
        },
        optimizeDeps: {
            include: ['vue', 'vue-router', 'pinia', 'vue-sweetalert2'],
        },
        cacheDir: '.vite',
    };
});