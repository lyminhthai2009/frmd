module.exports = {
  module: ["AuditLogs"],
  desc: ["One of the Heliactyl theme modules..."],
  plugins: [],
  additionalStyles: [],
}