module.exports = {
  module: ["Resources"],
  desc: ["One of the Heliactyl theme modules..."],
  plugins: [],
  additionalStyles: [],
}