module.exports = {
  module: ["Pages"],
  desc: ["One of the Heliactyl theme modules..."],
  plugins: [],
  additionalStyles: [],
}