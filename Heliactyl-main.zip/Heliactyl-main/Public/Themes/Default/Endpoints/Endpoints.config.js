module.exports = {
  module: ["Endpoints"],
  desc: ["One of the Heliactyl theme modules..."],
  plugins: [],
  additionalStyles: [],
}