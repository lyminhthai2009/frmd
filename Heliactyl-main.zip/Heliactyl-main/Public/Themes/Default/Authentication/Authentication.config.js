module.exports = {
  module: ["Authentication"],
  desc: ["One of the Heliactyl theme modules..."],
  plugins: [],
  additionalStyles: [],
}