ALTER TABLE `mythicaldash_tickets_attachments`
DROP `enabled`;