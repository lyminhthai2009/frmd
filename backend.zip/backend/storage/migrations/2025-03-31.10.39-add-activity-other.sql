ALTER TABLE `mythicaldash_users_activities`
ADD COLUMN `context` TEXT NOT NULL DEFAULT 'None';