SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `mythicaldash_invoices`;
DROP TABLE IF EXISTS `mythicaldash_orders`;
DROP TABLE IF EXISTS `mythicaldash_orders_config`;
DROP TABLE IF EXISTS `mythicaldash_services`;
DROP TABLE IF EXISTS `mythicaldash_services_categories`;
DROP TABLE IF EXISTS `mythicaldash_services_categories_features`;
DROP TABLE IF EXISTS `mythicaldash_services_price_types`;
DROP TABLE IF EXISTS `mythicaldash_services_upgrades`;
DROP TABLE IF EXISTS `mythicaldash_billing`;


SET FOREIGN_KEY_CHECKS=1;