ALTER TABLE `mythicaldash_eggs` DROP COLUMN IF EXISTS `image`;
ALTER TABLE `mythicaldash_locations` DROP COLUMN IF EXISTS `image`;
