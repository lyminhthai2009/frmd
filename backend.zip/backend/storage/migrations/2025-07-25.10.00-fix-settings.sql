ALTER TABLE `mythicaldash_settings` ADD UNIQUE(`name`);
