DROP TABLE `mythicaldash_analytics`, `mythicaldash_users_apikeys`;
