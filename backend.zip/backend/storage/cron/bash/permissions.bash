chown -R www-data:www-data /var/www/mythicaldash-v3/*
