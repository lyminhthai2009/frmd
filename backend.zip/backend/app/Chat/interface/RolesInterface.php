<?php

/*
 * This file is part of MythicalDash.
 * Please view the LICENSE file that was distributed with this source code.
 *
 * # MythicalSystems License v2.0
 *
 * ## Copyright (c) 2021–2025 MythicalSystems and Cassian Gherman
 *
 * Breaking any of the following rules will result in a permanent ban from the MythicalSystems community and all of its services.
 * Make sure to read the docs before making any changes. And note that any changes you make will be overwritten by the next update.
 *
 * Be careful with the code you write, and make sure to test it before committing it.
 *
 * Please rather than modifying the dashboard code try to report the thing you wish on our github or write a plugin
 */

namespace MythicalDash\Chat\interface;

/*
 * This file is part of MythicalDash.
 * Please view the LICENSE file that was distributed with this source code.
 *
 * # MythicalSystems License v2.0
 *
 * ## Copyright (c) 2021–2025 MythicalSystems and Cassian Gherman
 *
 * Breaking any of the following rules will result in a permanent ban from the MythicalSystems community and all of its services.
 */

class RolesInterface
{
    public static string $DEFAULT = 'default';
    public static string $VIP = 'vip';
    public static string $SUPPORTBUDDY = 'supportbuddy';
    public static string $SUPPORT = 'support';
    public static string $SUPPORTLVL3 = 'supportlvl3';
    public static string $SUPPORTLVL4 = 'supportlvl4';
    public static string $ADMIN = 'admin';
    public static string $ADMINISTRATOR = 'administrator';

    public static function getRoles(): array
    {
        return [
            self::$DEFAULT,
            self::$VIP,
            self::$SUPPORTBUDDY,
            self::$SUPPORT,
            self::$SUPPORTLVL3,
            self::$SUPPORTLVL4,
            self::$ADMIN,
            self::$ADMINISTRATOR,
        ];
    }
}
