<?php

/*
 * This file is part of MythicalDash.
 * Please view the LICENSE file that was distributed with this source code.
 *
 * # MythicalSystems License v2.0
 *
 * ## Copyright (c) 2021–2025 MythicalSystems and Cassian Gherman
 *
 * Breaking any of the following rules will result in a permanent ban from the MythicalSystems community and all of its services.
 * Make sure to read the docs before making any changes. And note that any changes you make will be overwritten by the next update.
 *
 * Be careful with the code you write, and make sure to test it before committing it.
 *
 * Please rather than modifying the dashboard code try to report the thing you wish on our github or write a plugin
 */

namespace MythicalDash\FastChat;

use Predis\Client;
use MythicalDash\App;

class Redis
{
    private $redis;

    public function __construct()
    {
        $app = App::getInstance(true);
        $app->loadEnv();
        if (isset($_ENV['REDIS_HOST']) && isset($_ENV['REDIS_PASSWORD'])) {
            $host = $_ENV['REDIS_HOST'] ?? 'localhost';
            $pwd = $_ENV['REDIS_PASSWORD'] ?? '';
            $client = new Client([
                'scheme' => 'tcp',
                'host' => $host,
            ]);
            $this->redis = $client;
        } else {
            $app->getLogger()->error('Redis connection failed');
        }
    }

    public function getRedis(): Client
    {
        return $this->redis;
    }

    public function testConnection(): bool
    {
        try {
            $redis = $this->getRedis();
            $redis->connect();

            return $redis->isConnected();
        } catch (\Exception $e) {
            App::getInstance(true)->getLogger()->error('Failed to connect to Redis: ' . $e->getMessage());

            return false;
        }
    }
}
