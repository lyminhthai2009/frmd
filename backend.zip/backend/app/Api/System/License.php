<?php

/*
 * This file is part of MythicalDash.
 * Please view the LICENSE file that was distributed with this source code.
 *
 * # MythicalSystems License v2.0
 *
 * ## Copyright (c) 2021–2025 MythicalSystems and Cassian Gherman
 *
 * Breaking any of the following rules will result in a permanent ban from the MythicalSystems community and all of its services.
 * Make sure to read the docs before making any changes. And note that any changes you make will be overwritten by the next update.
 *
 * Be careful with the code you write, and make sure to test it before committing it.
 *
 * Please rather than modifying the dashboard code try to report the thing you wish on our github or write a plugin
 */

use MythicalDash\App;
use MythicalDash\Config\ConfigInterface;

// NOTE: License server is down. All license checks are bypassed and will return true.

$router->add('/api/system/license/theme-customization', function (): void {
    App::init();
    App::OK('License is valid!', ['valid' => true]);
});

$router->add('/api/system/license/beta', function (): void {
    App::init();
    App::OK('License is valid!', ['valid' => true]);
});

$router->add('/api/system/license/branding-removal', function (): void {
    App::init();
    App::OK('License is valid!', ['valid' => true]);
});

$router->add('/api/system/license', function (): void {
    App::init();
    $appInstance = App::getInstance(true);
    $config = $appInstance->getConfig();
    
    // Return fake valid license data since the official server is down
    App::OK('License is valid!', [
        'valid' => true,
        'data' => [
            'project_info' => [
                'name' => 'MythicalDash Self-Hosted',
                'description' => 'Self-hosted license due to official server shutdown.',
                'features' => ['More Customization', 'Beta Features', 'Branding Removal'],
                'expires_at' => '2099-12-31 23:59:59',
            ],
            'instance_info' => [
                'companyName' => 'My Company',
                'companyWebsite' => $config->getDBSetting(ConfigInterface::APP_URL, ''),
                'instanceUrl' => $config->getDBSetting(ConfigInterface::APP_URL, ''),
                'abuseEmail' => 'abuse@example.com',
                'supportEmail' => 'support@example.com',
            ],
            'license_key_info' => [
                'expires_at' => '2099-12-31 23:59:59',
                'status' => 'active',
                'locked' => 'false',
                'deleted' => 'false',
            ],
        ],
    ]);
});